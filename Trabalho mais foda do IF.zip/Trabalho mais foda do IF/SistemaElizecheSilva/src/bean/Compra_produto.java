/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author Junior
 */
public class Compra_produto {
    private int idCompras_produto;
    private int quantidade;
    private String valor_unitario;
    private int compra;
    private int produto;

    /**
     * @return the idCompras_produto
     */
    public int getIdCompras_produto() {
        return idCompras_produto;
    }

    /**
     * @param idCompras_produto the idCompras_produto to set
     */
    public void setIdCompras_produto(int idCompras_produto) {
        this.idCompras_produto = idCompras_produto;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the valor_unitario
     */
    public String getValor_unitario() {
        return valor_unitario;
    }

    /**
     * @param valor_unitario the valor_unitario to set
     */
    public void setValor_unitario(String valor_unitario) {
        this.valor_unitario = valor_unitario;
    }

    /**
     * @return the compra
     */
    public int getCompra() {
        return compra;
    }

    /**
     * @param compra the compra to set
     */
    public void setCompra(int compra) {
        this.compra = compra;
    }

    /**
     * @return the produto
     */
    public int getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(int produto) {
        this.produto = produto;
    }
}
