/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;



/**
 *
 * @author Junior
 */
public class Venda_produto {
    private int idVenda_produto;
    private int quantidade;
    private String valor_unitario;
    private int venda;
    private int produto;

    /**
     * @return the idVenda_produto
     */
    public int getIdVenda_produto() {
        return idVenda_produto;
    }

    /**
     * @param idVenda_produto the idVenda_produto to set
     */
    public void setIdVenda_produto(int idVenda_produto) {
        this.idVenda_produto = idVenda_produto;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the valor_unitario
     */
    public String getValor_unitario() {
        return valor_unitario;
    }

    /**
     * @param valor_unitario the valor_unitario to set
     */
    public void setValor_unitario(String valor_unitario) {
        this.valor_unitario = valor_unitario;
    }

    /**
     * @return the venda
     */
    public int getVenda() {
        return venda;
    }

    /**
     * @param venda the venda to set
     */
    public void setVenda(int venda) {
        this.venda = venda;
    }

    /**
     * @return the produto
     */
    public int getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(int produto) {
        this.produto = produto;
    }
}
