/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Venda_produto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Junior
 */
public class Venda_produto_DAO extends DAO_Abstract {
    public void insert(Object object) {
       Venda_produto venda_produto = (Venda_produto) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Venda_produto values (?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, venda_produto.getIdVenda_produto() );
                pstm.setInt(2, venda_produto.getQuantidade() );
                pstm.setString(3, venda_produto.getValor_unitario() );
                pstm.setInt(4, venda_produto.getVenda() );
                pstm.setInt(5, venda_produto.getProduto() );
                pstm.executeUpdate();
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Venda_produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Venda_produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     public static void main(String[] args) {
        Venda_produto venda_produto = new Venda_produto();
        venda_produto.setIdVenda_produto(1);
        venda_produto.setQuantidade(1);
        venda_produto.setValor_unitario("8500");
        venda_produto.setVenda(1);
        venda_produto.setProduto(1);
   
       
        Venda_produto_DAO venda_produto_DAO = new Venda_produto_DAO();
        venda_produto_DAO.insert(venda_produto);
        System.out.println("deu certo");
 
}
}
