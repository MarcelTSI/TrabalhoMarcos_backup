/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import teste.TesteJDBC;
import bean.Usuarios;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcelbenitezdasilva
 */
public class Usuarios_DAO extends DAO_Abstract {

    
    @Override
    public void insert(Object object) {

        Usuarios usuarios = (Usuarios) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
       url = "jdbc:mysql://localhost:3306/db_marcel_silva";
       user = "root";
       password = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            String sql = "insert into Usuario values (?,?,?,?,?,?,?,?)";
           PreparedStatement pstm = cnt.prepareStatement(sql);
           pstm.setInt(1, usuarios.getIdUsuario() );
           pstm.setString(2, usuarios.getNome() );
           pstm.setString(3, usuarios.getApelido() );
           pstm.setString(4, usuarios.getCpf() );
           pstm.setDate(5, new Date(2001,1,1) );
           pstm.setString(6, usuarios.getSenha() );
           pstm.setInt(7, usuarios.getNivel() );
           pstm.setString(8, usuarios.getAtivo() );
           pstm.executeUpdate();
           
           

        } catch (ClassNotFoundException ex) {
            System.out.print("erro na conexão");
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public static void main(String[] args) {
        Usuarios usuarios = new Usuarios();
        usuarios.setIdUsuario(3);
        usuarios.setNome("instrumentaliza");
        usuarios.setApelido("Loja");
        usuarios.setCpf("12345678910");
        //usuarios.setDataNascimento("");
        usuarios.setSenha("senha");
        usuarios.setNivel(10);
        usuarios.setAtivo("S");
        
         Usuarios_DAO usuarios_DAO = new Usuarios_DAO();
        usuarios_DAO.insert(usuarios);
        System.out.println("deu certo");
    }
}
