/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Compra_produto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Junior
 */
public class Compra_produto_DAO extends DAO_Abstract {
    public void insert(Object object) {
        Compra_produto compra_produto = (Compra_produto) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Compra_produto values (?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, compra_produto.getIdCompras_produto() );
                pstm.setInt(2, compra_produto.getQuantidade() );
                pstm.setString(3, compra_produto.getValor_unitario() );
                pstm.setInt(4, compra_produto.getCompra() );
                pstm.setInt(5, compra_produto.getProduto() );
                pstm.executeUpdate();
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Compra_produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Compra_produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
       public static void main(String[] args) {
        Compra_produto compra_produto = new Compra_produto();
        compra_produto.setIdCompras_produto(1);
        compra_produto.setQuantidade(1);
        compra_produto.setValor_unitario("7900");
        compra_produto.setCompra(1);
        compra_produto.setProduto(1);
        
   
       
        Compra_produto_DAO compra_produto_DAO = new Compra_produto_DAO();
        compra_produto_DAO.insert(compra_produto);
        System.out.println("deu certo");
 
}
 
}

