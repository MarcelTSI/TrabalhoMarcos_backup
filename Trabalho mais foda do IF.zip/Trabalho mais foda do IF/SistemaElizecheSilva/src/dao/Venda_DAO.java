/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Venda;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Junior
 */
public class Venda_DAO extends DAO_Abstract {
    @Override
    public void insert(Object object) {
       Venda venda = (Venda) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Venda values (?,?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, venda.getIdVenda() );
                 pstm.setDate(2, new Date(2001,1,1) );
                pstm.setString(3, venda.getValor_total() );
                pstm.setString(4, venda.getQuantidade_venda() );
                pstm.setInt(5, venda.getCliente() );
                pstm.setInt(6, venda.getFuncionario() );
                pstm.executeUpdate();
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Venda_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Venda_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     public static void main(String[] args) {
        Venda venda = new Venda();
        venda.setIdVenda(1);
        //venda.setData_venda();
        venda.setValor_total("8500");
        venda.setQuantidade_venda("1");
        venda.setCliente(1);
        venda.setFuncionario(1);
   
       
        Venda_DAO venda_DAO = new Venda_DAO();
        venda_DAO.insert(venda);
        System.out.println("deu certo");
 
}
}
