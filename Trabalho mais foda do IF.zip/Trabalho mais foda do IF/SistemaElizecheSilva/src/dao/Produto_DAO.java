/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Produto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Junior
 */
public class Produto_DAO extends DAO_Abstract {
    public void insert(Object object) {
       Produto produto = (Produto) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Produto values (?,?,?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, produto.getIdProduto() );
                pstm.setString(2, produto.getNome() );
                pstm.setString(3, produto.getDescricao() );
                pstm.setString(4, produto.getPreco() );
                pstm.setInt(5, produto.getQuantidade() );
                pstm.setString(6, produto.getTipo() );
                pstm.setInt(7, produto.getCategoria() );
                pstm.executeUpdate();
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Produto_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static void main(String[] args) {
        Produto produto = new Produto();
        produto.setIdProduto(1);
        produto.setNome("Pearl Decade Maple");
        produto.setDescricao("Bateria que é o sonho do Marcel e do Claudin");
        produto.setPreco("7900");
        produto.setQuantidade(1);
        produto.setTipo("Bateria");
        produto.setCategoria(1);
   
       
        Produto_DAO produto_DAO = new Produto_DAO();
        produto_DAO.insert(produto);
        System.out.println("deu certo");
 
}
    
}
