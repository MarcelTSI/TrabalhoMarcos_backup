/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Compra;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import teste.TesteJDBC;

/**
 *
 * @author ninoc
 */
public class Compra_DAO extends DAO_Abstract {

    @Override
    public void insert(Object object) {
        
        Compra compra = (Compra) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
       url = "jdbc:mysql://localhost:3306/db_marcel_silva";
       user = "root";
       password = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            String sql = "insert into Compra values (?,?,?,?,?,?)";
            PreparedStatement pstm = cnt.prepareStatement(sql);
            pstm.setInt(1, compra.getIdCompra() );
            pstm.setDate(2, new Date(2023,1,1) );
            pstm.setInt(3, compra.getProduto_comprado());
            pstm.setString(4, compra.getPreco_compra());
            pstm.setInt(5, compra.getQuantidade_compra());
            pstm.setInt(6, compra.getFornecedor() );
            pstm.executeUpdate();
           
           

        } catch (ClassNotFoundException ex) {
            System.out.print("erro na conexão");
            Logger.getLogger(Compra_DAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Compra_DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public static void main(String[] args) {
        Compra compra = new Compra();
        compra.setIdCompra(1);
        //compra.setData_compra("");
        compra.setProduto_comprado(1);
        compra.setPreco_compra("7900");
        compra.setQuantidade_compra(1);
        compra.setFornecedor(1);
        

        
         Compra_DAO compra_DAO = new Compra_DAO();
        compra_DAO.insert(compra);
        System.out.println("deu certo");
    }
}
