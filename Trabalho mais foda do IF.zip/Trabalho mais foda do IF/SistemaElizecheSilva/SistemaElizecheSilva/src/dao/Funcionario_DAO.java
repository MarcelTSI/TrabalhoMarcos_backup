/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Funcionario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import teste.TesteJDBC;

/**
 *
 * @author ninoc
 */
public class Funcionario_DAO extends DAO_Abstract {

    @Override
    public void insert(Object object) {
        
        Funcionario funcionario = (Funcionario) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
       url = "jdbc:mysql://localhost:3306/db_marcel_silva";
       user = "root";
       password = "";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            String sql = "insert into Funcionario values (?,?,?,?,?)";
           PreparedStatement pstm = cnt.prepareStatement(sql);
           pstm.setInt(1, funcionario.getIdFuncionario() );
           pstm.setString(2, funcionario.getNome() );
           pstm.setString(3, funcionario.getEndereco() );
           pstm.setString(4, funcionario.getCpf() );
           pstm.setString(5, funcionario.getApelido() );
           pstm.executeUpdate();
           
           

        } catch (ClassNotFoundException ex) {
            System.out.print("erro na conexão");
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static void main(String[] args) {
        Funcionario funcionario = new Funcionario();
        funcionario.setIdFuncionario(1);
        funcionario.setNome("joao");
        funcionario.setEndereco("Avenida Brasil");
        funcionario.setCpf("02821334556");
        funcionario.setApelido("Joãozin");
        
        Funcionario_DAO funcionario_DAO = new Funcionario_DAO();
        funcionario_DAO.insert(funcionario);
        System.out.println("deu certo");
    }
    
    
}
