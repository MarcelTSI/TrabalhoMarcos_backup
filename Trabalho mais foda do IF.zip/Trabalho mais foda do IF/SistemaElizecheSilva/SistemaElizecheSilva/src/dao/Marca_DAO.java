/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Marca;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ninoc
 */
public class Marca_DAO extends DAO_Abstract {

    @Override
    public void insert(Object object) {
        Marca marca = (Marca) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Marca values (?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, marca.getIdMarcas() );
                pstm.setString(2, marca.getNome() );
                pstm.setString(3, marca.getDescricao() );
                pstm.setString(4, marca.getPais_origem() );
                pstm.setDate(5, new Date(2001,1,1) );
                pstm.executeUpdate();
                
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Categoria_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Categoria_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
    }

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
 public static void main(String[] args) {
        Marca marca = new Marca();
        marca.setIdMarcas(1);
        marca.setNome("pearl");
        marca.setDescricao("a melhor bateria");
        marca.setPais_origem("USA");
        //marca.setData_criacao();

        
        Marca_DAO marca_DAO = new Marca_DAO();
        marca_DAO.insert(marca);
        System.out.println("deu certo");
        
    }
    
}
