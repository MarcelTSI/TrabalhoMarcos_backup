/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Categoria;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ninoc
 */
public class Categoria_DAO extends DAO_Abstract {

    @Override
    public void insert(Object object) {
        
        Categoria categoria = (Categoria) object;
        
        String url, user, password;
        //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
        //user = "marcel_silva";
        //password = "marcel_silva";
        
        url = "jdbc:mysql://localhost:3306/db_marcel_silva";
        user = "root";
        password = "";
        
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection cnt;
                cnt = DriverManager.getConnection(url, user, password);
                String sql = "insert into Categoria values (?,?,?,?,?,?)";
                PreparedStatement pstm = cnt.prepareStatement(sql);
                pstm.setInt(1, categoria.getIdCategoria() );
                pstm.setString(2, categoria.getNome() );
                pstm.setString(3, categoria.getDescricao() );
                pstm.setString(4, categoria.getAtiva() );
                pstm.setString(5, categoria.getTamanho() );
                pstm.setString(6, categoria.getMaterial() );
                pstm.executeUpdate();
                
                
               
                
            } catch (ClassNotFoundException ex) {
                System.out.print("erro na conexão");
                Logger.getLogger(Categoria_DAO.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Categoria_DAO.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    

    @Override
    public void update(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List listAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public static void main(String[] args) {
        Categoria categoria = new Categoria();
        categoria.setIdCategoria(1);
        categoria.setNome("bateria");
        categoria.setDescricao("Pearl");
        categoria.setAtiva("S");
        categoria.setTamanho("Grande");
        categoria.setMaterial("Madeira");

        
         Categoria_DAO categoria_DAO = new Categoria_DAO();
        categoria_DAO.insert(categoria);
        System.out.println("deu certo");
        
    }
    
}
