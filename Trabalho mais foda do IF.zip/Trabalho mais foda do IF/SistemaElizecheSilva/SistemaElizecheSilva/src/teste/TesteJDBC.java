/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author marcelbenitezdasilva
 */
public class TesteJDBC {
    public static void main(String[] args) {
        String url, user, password;
       //url = "jdbc:mysql://10.7.0.51:33062/db_marcel_silva";
      // user = "marcel_silva";
       //password = "marcel_silva"; 
        
       url = "jdbc:mysql://localhost:3306/db_marcel_silva";
       user = "root";
       password = "";
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cnt;
            cnt = DriverManager.getConnection(url, user, password);
            Statement stm ;
            stm = cnt.createStatement();
            String sql = "insert into Usuario values (4,'Claudio','Jotta','12345678910','2005-11-17','12345678',1,'S')";
            stm.executeUpdate(sql);

                   
                    } catch (ClassNotFoundException ex) {
                        System.out.print("erro na conexão");
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TesteJDBC.class.getName()).log(Level.SEVERE, null, ex);
        }  
        System.out.print("conectou ");
    }
}
