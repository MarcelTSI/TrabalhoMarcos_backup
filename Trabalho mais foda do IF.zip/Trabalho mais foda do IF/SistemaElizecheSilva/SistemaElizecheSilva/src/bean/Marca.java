/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.Date;

/**
 *
 * @author ninoc
 */
public class Marca {
    
    private int idMarcas;
    private String nome;
    private String descricao;
    private String pais_origem;
    private Date data_criacao;

    /**
     * @return the idMarcas
     */
    public int getIdMarcas() {
        return idMarcas;
    }

    /**
     * @param idMarcas the idMarcas to set
     */
    public void setIdMarcas(int idMarcas) {
        this.idMarcas = idMarcas;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the pais_origem
     */
    public String getPais_origem() {
        return pais_origem;
    }

    /**
     * @param pais_origem the pais_origem to set
     */
    public void setPais_origem(String pais_origem) {
        this.pais_origem = pais_origem;
    }

    /**
     * @return the data_criacao
     */
    public Date getData_criacao() {
        return data_criacao;
    }

    /**
     * @param data_criacao the data_criacao to set
     */
    public void setData_criacao(Date data_criacao) {
        this.data_criacao = data_criacao;
    }
    
}
