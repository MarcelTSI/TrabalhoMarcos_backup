/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.Date;

/**
 *
 * @author ninoc
 */
public class Compra {
    
    private int idCompra;
    private Date data_compra;
    private int produto_comprado;
    private int preco_compra;
    private int quantidade_compra;
    private int fornecedor;
    


    /**
     * @return the idCompra
     */
    public int getIdCompra() {
        return idCompra;
    }

    /**
     * @param idCompra the idCompra to set
     */
    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    /**
     * @return the data_compra
     */
    public Date getData_compra() {
        return data_compra;
    }

    /**
     * @param data_compra the data_compra to set
     */
    public void setData_compra(Date data_compra) {
        this.data_compra = data_compra;
    }

    /**
     * @return the produto_comprado
     */
    public int getProduto_comprado() {
        return produto_comprado;
    }

    /**
     * @param produto_comprado the produto_comprado to set
     */
    public void setProduto_comprado(int produto_comprado) {
        this.produto_comprado = produto_comprado;
    }

    /**
     * @return the preco_compra
     */
    public int getPreco_compra() {
        return preco_compra;
    }

    /**
     * @param preco_compra the preco_compra to set
     */
    public void setPreco_compra(int preco_compra) {
        this.preco_compra = preco_compra;
    }

    /**
     * @return the quantidade_compra
     */
    public int getQuantidade_compra() {
        return quantidade_compra;
    }

    /**
     * @param quantidade_compra the quantidade_compra to set
     */
    public void setQuantidade_compra(int quantidade_compra) {
        this.quantidade_compra = quantidade_compra;
    }

    /**
     * @return the fornecedor
     */
    public int getFornecedor() {
        return fornecedor;
    }

    /**
     * @param fornecedor the fornecedor to set
     */
    public void setFornecedor(int fornecedor) {
        this.fornecedor = fornecedor;
    }

    public void setPreco_compra(int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
    